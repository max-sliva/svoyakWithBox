# JavaFX Custom Controls
<b>Font Picker</b></br></br>
![alt tag](https://raw.githubusercontent.com/farrukh-obaid/custom-controls/master/screenshots/font-picker.gif)
